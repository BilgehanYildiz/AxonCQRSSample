package com.example.reader.bll;

import com.example.reader.model.TestEntity;
import com.example.reader.query.FindTestEntityQuery;
import org.axonframework.eventsourcing.eventstore.EventStore;
import org.axonframework.messaging.Message;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.queryhandling.QueryGateway;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class TestService {
    private final QueryGateway queryGateway;
    private final EventStore eventStore;

    public TestService(QueryGateway queryGateway,EventStore eventStore)
    {
        this.queryGateway=queryGateway;
        this.eventStore=eventStore;
    }

    public CompletableFuture<TestEntity> findById(String eventid) {
        return this.queryGateway.query(
                new FindTestEntityQuery(eventid),
                ResponseTypes.instanceOf(TestEntity.class)
        );
    }

    public List<Object> listEventsForTestEntity(String eventid) {
        return this.eventStore
                .readEvents(eventid)
                .asStream()
                .map(Message::getPayload)
                .collect(Collectors.toList());
    }
}
