package com.example.reader.controller;

import com.example.reader.bll.TestService;
import com.example.reader.model.TestEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("api/reader")
public class TestReaderController {

    @Autowired
    private TestService testService;

    @GetMapping("/{eventid}")
    public CompletableFuture<TestEntity> findById(@PathVariable("eventid") String eventid) {
        return this.testService.findById(eventid);
    }

    @GetMapping("/{eventid}/events")
    public List<Object> listEventsForAccount(@PathVariable(value = "eventid") String eventid) {
        return this.testService.listEventsForTestEntity(eventid);
    }
}
