package com.example.reader.query;

public class FindTestEntityQuery {
    private String eventid;

 public FindTestEntityQuery(String eventid)
 {
     this.setEventid(eventid);
 }

    public String getEventid() {
        return eventid;
    }

    public void setEventid(String eventid) {
        this.eventid = eventid;
    }
}
