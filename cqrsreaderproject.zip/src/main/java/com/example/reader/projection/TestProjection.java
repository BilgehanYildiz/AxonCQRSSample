package com.example.reader.projection;

import com.example.reader.model.TestEntity;
import com.example.reader.query.FindTestEntityQuery;
import com.example.reader.repository.TestRepository;
import org.axonframework.queryhandling.QueryHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TestProjection {

    @Autowired
    private  TestRepository testRepository;

    @QueryHandler
    public TestEntity handle(FindTestEntityQuery query) {
        System.out.println("query: {}"+query);
        return this.testRepository.findByEventID(query.getEventid());
    }
}
